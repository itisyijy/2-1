package employee;

public class FullTimeEmp {
	// declare fields here
	
	public FullTimeEmp() {
	// implement here
	}

	public FullTimeEmp(int id, String name, DepartmentEnum department, PositionEnum position, int grade) {
// implement here
	}
	

	public void print() {
// implement here
	}
}
