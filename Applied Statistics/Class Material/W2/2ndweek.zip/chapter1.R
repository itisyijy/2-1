install.packages("Devore7")
library(Devore7)
str(xmp01.05)
with(xmp01.05, summary(bingePct))
with(xmp01.05, stem(bingePct)) 

sample(1:60, 5)

with(xmp01.09, hist(consump, xlab="Adjusted energy consumption"))
hist(xmp01.09$consump, xlab="Adjusted energy consumption")

d <- density(xmp01.09$consump) 
plot(d) 

str(ex01.29)
with(ex01.29, barplot(table(C1), horiz=TRUE))

duration <- c(62.3, 62.8, 63.6, 65.2, 65.7, 66.4, 67.4, 68.4, 68.8, 70.8, 75.7, 79.0)
duration
summary(duration)

quantile(duration, probs=0.75)

x <-  c(61,58,78,71,72,92,66,83,70,83,78,81,74,85,89,98, 97,141,126,112)
summary(x)
sort(x)
boxplot(x)

with(xmp10.01, boxplot(C1 ~ as.factor(C2), horizontal=T))

