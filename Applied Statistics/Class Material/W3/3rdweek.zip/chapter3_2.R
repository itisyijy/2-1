pbinom(2, 10, 0.5)

prob <- c(0.01, 0.03, 0.13, 0.25, 0.39, 0.17, 0.02)
sum(prob)
sum(1:7 * prob) 

sum(1:40 * dgeom(0:39, prob=0.5)) 
dgeom(3, prob=0.5) 
(1-0.5)^3*0.5

pbinom(3, 10, 0.5)
pbinom(4, 10, 0.5)
qbinom(0.3, 10, 0.5)

sum(dbinom(0:8, size=15, prob=0.2))
pbinom(8, 15, 0.2)
dbinom(8, 15, 0.2)
pbinom(8, 15, 0.2)-pbinom(7, 15, 0.2)

sum(dbinom(8:15, 15, 0.2))
pbinom(7.5, 15, 0.2, lower=FALSE) 
1-pbinom(7, 15, 0.2) 
sum(dbinom(4:7, 15, 0.2)) 
sum(0:15 * dbinom(0:15, 15, 0.2)) 
mean = 0
for(i in 0:15){
   mean = mean + i * dbinom(i, 15, 0.2)
}
mean 

mean = 0
for(i in 0:15){
  mean = mean + i * dbinom(i, 15, 0.2)
}
mean 

sum((0:15 - 15*0.2)^2 * dbinom(0:15, 15, 0.2))
var = 0
for(i in 0:15){
   var = var + (i-15*0.2)^2 * dbinom(i, 15, 0.2)
}
var

c(expected = 15*0.2, variance=15*0.2*0.8)



m_binom <- function(n, p){
  mean = 0
  for(i in 0:n){
    mean = mean + i * dbinom(i, n, p)
  }
  return(mean )
}

m_binom(20, 0.2)

v_binom <- function(n, p){
  var = 0
  for(i in 0:n){
    var = var + (i-n*p)^2 * dbinom(i, n, p)
  }
  return(var)
}

v_binom(20, 0.2)



dpois(5, 4.5)
sum(dpois(0:5, 4.5))
ppois(5, 4.5)

dbinom(1, 400, 0.005)
dpois(1, lambda=2) 
sum(dbinom(0:3, 400, 0.005)) 
sum(dpois(0:3, lambda=2)) 


