dbinom(3, 10, 0.5)
factorial(10)/(factorial(3)*factorial(7))*0.5^3*0.5^7 
factorial(3)
pnorm(1)
pnorm(1)-pnorm(-1)
qnorm(0.8413)
qnorm(0.5)
1/sqrt(2*pi)*exp(-1/2)
dnorm(1)

rnorm(10)
dbinom(0, 10, 0.5)
dbinom(1, 10, 0.5)
dbinom(2, 10, 0.5)
pbinom(2, 10, 0.5)

